Bladestar Campaign Beta Readme

I. System Requirements

Windows 2000 or Windows XP 
If you have an earlier operating system, you may have problems with the graphics disappearing at odd times, or just looking really weird.
If this happens, contact me at ben.christel@pacbell.net and I will send you a version that will hopefully work.
A reasonably fast processor (1 mhz will probably do.  More information on this will be forthcoming once I have tested on various machines.)
Some RAM - 256 mb is plenty
Some hard drive space

You absolutely need 1280 x 1024 screen res to run Bladestar.  If you don't have it you suck and need a new monitor.

II. Installation

To install Bladestar, copy the whole folder labelled "Bladestar Package" from the CD-ROM to your hard drive or desktop.
Do NOT remove the .exe file from the folder, or edit or delete anything in the "Graphics" folder.
If you want quick access to the program, put the package folder on your desktop or create a shortcut.

III. Troubleshooting

If this program just won't run on your computer then there's not much I can do, but if you notice anything weird or not right (as in a bug),
contact me at ben.christel@pacbell.net and I will correct it in the next-released version.

IV. Copyright

Since this is a beta version, I am putting it out into the world for free distribution to all and sundry.  However, you may not sell it,
charge people to play your copy of it, or in any other way make money off of it.  If you are reading this and you bought this game
from someone else you should be aware that you just got ripped off.
